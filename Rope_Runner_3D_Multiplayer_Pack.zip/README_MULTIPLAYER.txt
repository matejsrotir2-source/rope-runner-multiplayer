# Rope Runner 3D – Multiplayer

## Co funguje
- Hráči se připojí do společné online session.
- Ostatní hráči se zobrazují ve 3D světě a jejich pozice se průběžně synchronizuje.
- Přezdívky se zobrazují nad postavami.

## Co zatím není sdílené
Mise, peníze, auta, NPC, zbraně, zásahy a postup ve hře zůstávají na každém hráči lokální. Tohle je první multiplayerová verze zaměřená na společný pohyb po mapě.

## Spuštění serveru
Potřebuješ Node.js 18 nebo novější.

```bash
npm install
npm start
```

Pak otevři `http://localhost:8080` na počítači. Další hráči se připojí přes stejnou veřejnou adresu serveru.

## Zveřejnění na internetu
Pro hraní přes internet musíš server nasadit na hosting, který podporuje Node.js a WebSockety (např. VPS nebo Node hosting). Nastav proměnnou `PORT`, pokud hosting přidělí vlastní port. Hráči pak otevřou veřejnou HTTPS adresu; WebSocket se automaticky přepne na zabezpečené WSS.

Samotný HTML soubor nestačí pro multiplayer – server `server.js` musí běžet nepřetržitě.

## Admin: Matýsek (dočasné dary hráčům)
- Po přihlášení jako Matýsek se po připojení k serveru objeví tlačítko "Hráči".
- Heslo ověřuje server (ADMIN_HASH v server.js nebo proměnná prostředí ADMIN_HASH), ne jen prohlížeč.
- Matýsek může vybranému hráči (nebo všem) dát: peníze, zbraň, aimbot (ON/OFF) a skin.
- Dary platí jen do odpojení: po opuštění serveru se peníze, zbraně, aimbot i skin vrátí zpět a neukládají se do localStorage.
- Používej HTTPS/WSS, aby heslo cestovalo šifrovaně.

## Chat
- Tlačítko "💬 Chat" (nebo klávesa C / Enter) otevře okno s rychlými frázemi a políčkem pro vlastní zprávu (max. 100 znaků).
- Zprávu uvidí všichni hráči ve stejné místnosti v levém dolním rohu a po 12 s zmizí.
- Server omezuje spam (1 zpráva za 0,8 s). Jméno odesílatele určuje server; Matýsek je zlatě.
- Po úpravě je potřeba restartovat server (server.js se změnil).

## Banka (mise "Vykradení banky")
- Banka stojí uprostřed města (mezi paneláky, vchod ze strany silnice u startu). Hřiště, které tam bylo, se přesunulo o kus dál.
- Mise je v menu Mise (je volitelná, nespouští se automaticky po ostatních). Odměna $100 000, jde opakovat.
- Postup: vejdi do banky -> vybav si zbraň (B) a drž MÍŘ na bankéře za pultem (cca 1 s) -> bankéř tě odvede k trezoru a otevře ho -> seber peníze -> uteč 100 m na jih/sever k oranžové značce (policie jede po tobě).
- Ochranka (4 ozbrojení bodyguardi) si všimne zbraně v ruce, nebo se spustí po namíření / střelbě. Střílí po tobě a umí tě zabít (respawn = mise se resetuje). Za zabité strážce dostaneš bonus.
- Časový limit od začátku loupeže: 200 s.
- Minigun stojí $1 000 000.
- Pozor: mise, ochranka i peníze jsou lokální pro každého hráče (stejně jako ostatní mise).
