# Rope Runner 3D – Multiplayer

## Co funguje
- Hráči se připojí do společné online session.
- Ostatní hráči se zobrazují ve 3D světě a jejich pozice se průběžně synchronizuje.
- Přezdívky se zobrazují nad postavami.

## Co zatím není sdílené
Mise, peníze, auta, NPC, zbraně, zásahy a postup ve hře zůstávají na každém hráči lokální. Tohle je první multiplayerová verze zaměřená na společný pohyb po mapě.

## Spuštění serveru
Potřebuješ Node.js 18 nebo novější.

```bash
npm install
npm start
```

Pak otevři `http://localhost:8080` na počítači. Další hráči se připojí přes stejnou veřejnou adresu serveru.

## Zveřejnění na internetu
Pro hraní přes internet musíš server nasadit na hosting, který podporuje Node.js a WebSockety (např. VPS nebo Node hosting). Nastav proměnnou `PORT`, pokud hosting přidělí vlastní port. Hráči pak otevřou veřejnou HTTPS adresu; WebSocket se automaticky přepne na zabezpečené WSS.

Samotný HTML soubor nestačí pro multiplayer – server `server.js` musí běžet nepřetržitě.

## Admin: Matýsek (dočasné dary hráčům)
- Po přihlášení jako Matýsek se po připojení k serveru objeví tlačítko "Hráči".
- Heslo ověřuje server (ADMIN_HASH v server.js nebo proměnná prostředí ADMIN_HASH), ne jen prohlížeč.
- Matýsek může vybranému hráči (nebo všem) dát: peníze, zbraň, aimbot (ON/OFF) a skin.
- Dary platí jen do odpojení: po opuštění serveru se peníze, zbraně, aimbot i skin vrátí zpět a neukládají se do localStorage.
- Používej HTTPS/WSS, aby heslo cestovalo šifrovaně.
